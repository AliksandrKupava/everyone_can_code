﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace ShoppingCartHost
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(ShoppingCartService.ShoppingCartServiceImpl));
            host.Open();
            ServiceHost routerHost = new ServiceHost(typeof(ShoppingCartServiceRouter.Router));
            routerHost.Open();
            Console.WriteLine("Service running");
            Console.WriteLine("Press ENTER to stop the service");
            Console.ReadLine();
            host.Close();
        }
    }
}
